/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema
        .createTable('users', function (table) {
            table.increments('id').primary();
            table.string('name', 20).notNullable();
            table.string("password", 255).notNullable();
            table.string("email", 200).unique().notNullable();
            table.string("contact", 20).notNullable();
            table.enu('status', [0,1]).defaultTo(1).comment('0 = inactive , 1 = active' );
            table.timestamp('created_at').defaultTo(knex.fn.now());
            table.timestamp('updated_at').defaultTo(knex.fn.now());
        });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.dropTable('users');
};
