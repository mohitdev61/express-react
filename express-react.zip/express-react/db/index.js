require('dotenv').config();
const knex = require('knex');
const knexConfig = require('../knexfile');

// Use the loaded environment-specific variables
const environment = process.env.NODE_ENV || 'development';
const db = knex(knexConfig[environment]);

module.exports = db;