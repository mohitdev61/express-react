const {success, error } = require('response');

module.exports = {
    success: responses,
    error: common,
    activityResponse: activityResponse,
  };