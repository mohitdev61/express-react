const { success, error } = require('../helpers/response.js')
const jwt = require('jsonwebtoken');
require('dotenv');

const auth = (request, response, next) => {
  try {
    let token = request.headers.authorization;
    if (token) {
      token = token.split(' ')[1];
      jwt.verify(token, process.env.JWT_SECRET_KEY, (error, data) => {

        if (error) {
          return error(response, "You token is invalid!");
        }
        request.data = data
        next();
      });
    } else {
      return error(response, { message: "Unauthorized", status: 401 });
    }
  } catch (err) {
    return error(response, err.message);
  }
};

module.exports = auth;