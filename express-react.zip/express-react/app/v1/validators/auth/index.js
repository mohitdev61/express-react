const { KnexCount } = require("../Knex/KnexQuery");

const RegisterValidate = {
    name: {
        notEmpty: {
            errorMessage: 'Name is required',
        },
        isString: {
            errorMessage: 'Name must be a string.'
        },
        isLength: {
            options: { min: 5, max: 20 },
            errorMessage: 'Please enter at minium 5 and maximum 20 characters.'
        }
    },
    business_name: {
        notEmpty: {
            errorMessage: 'Business Name is required.',
        }
    },
    email: {
        notEmpty: {
            errorMessage: 'E-mail is required.',
        },
        custom: {
            options: (value) => {
                return KnexCount({ table: 'users', where: { email: value } }).then(user => {
                    if (user[0].id) {
                        return Promise.reject(
                          `Emails already exist. Please try another email.`
                        );
                    }
                })
            },
        },
        isEmail: {
            errorMessage: 'E-mail is not valid.',
        },
    },
    business_contact: {
        notEmpty: {
            errorMessage: 'Business contact no is required.',
        },
        isMobilePhone: {
            errorMessage: 'Please enter a valid phone number.'
        }
    },
    business_type: {
        notEmpty: {
            errorMessage: 'Business type no is required.',
        }
    },
    password: {
        isStrongPassword: {
            minLength: 8,
            minLowercase: 1,
            minUppercase: 1,
            minNumbers: 1,
        },
        errorMessage:
            "Password must be greater than 8 and contain at least one uppercase letter, one lowercase letter, and one number"
    }
    
}


const LoginValidate = {
    email: {
        notEmpty: {
            errorMessage: 'E-mail is required.',
        },
        isEmail: {
            errorMessage: 'E-mail is not valid.',
        }
    },
    password: {
        notEmpty: {
            errorMessage: 'Password is required .',
        }
    }
}

const ForgotPasswordValidate = {
    email: {
        notEmpty: {
            errorMessage: 'E-mail is required.',
        },
        isEmail: {
            errorMessage: 'E-mail is not valid.',
        }
    }
}

const ResetPasswordValidate = {
    password: {
        isStrongPassword: {
            minLength: 8,
            minLowercase: 1,
            minUppercase: 1,
            minNumbers: 1,
        },
        errorMessage:
            "Password must be greater than 8 and contain at least one uppercase letter, one lowercase letter, and one number"
    },
    token: {
        notEmpty: {
            errorMessage: 'E-mail is required.',
        }
    }

    
}

module.exports = {
    RegisterValidate,
    LoginValidate,
    ForgotPasswordValidate,
    ResetPasswordValidate
}