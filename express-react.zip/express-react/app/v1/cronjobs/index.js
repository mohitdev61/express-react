const cron = require('node-cron');
const axios = require('axios');
require('dotenv').config({ path: '.env.dev' });

console.log(process.env.APP_URL + 'users')

const task = cron.schedule('*/1 * * * *', () => {
    // This function will run cron job after every 3 minute
    axios.post(process.env.APP_URL + 'users')
        .then(response => {
            if (response.data.success == true) {
                console.log(response.data);
            } else {
                console.log(response.data.error.message);
            }
        }).catch(error => {
            console.error(error);
        });
});

// Start the task
task.start();