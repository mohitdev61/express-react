const db = require('../../../db');
const { success, error } = require('../helpers/response.js')
const _ = require("lodash");
exports.testLodash = [
  async (request, response) => {
    try {
      var numbers = request.body;
      var listOfNumbers = '';
      
      listOfNumbers = _.concat(numbers, 5);
      // console.log(listOfNumbers);
      console.log("break here ----");
      listOfNumbers = _.chunk(numbers, 2);
      // console.log(listOfNumbers);
      listOfNumbers = _.compact(numbers);
      console.log(listOfNumbers)
      return success(response, numbers, 201, "data success.");
    } catch (err) {
      return error({ message: err.message });
    }
  },
];
