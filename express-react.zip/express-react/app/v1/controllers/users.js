const db = require('../../../db');
const { success, error } = require('../helpers/response.js')

exports.totalUsers = [
  async (request, response) => {
    try {
      const dummyUser = request.body;
      return success(response, dummyUser, 201, "data success.");
    } catch (err) {
      return error({ message: err.message });
    }
  },
];

exports.addUsers = [
  async (request, response) => {
    try {
      console.log(request.data, "--------------yesyesyeysyeyesyeyeys");
      const dummyUser = generateRandomData();
      // const newUser = await db('users').insert(dummyUser);
      const newUser = "fdsfsd";
      return success(response, request.data, 201, "data success.");
    } catch (err) {
      return error(response, err.message );
    }
  },
];

function generateRandomData() {
  const names = ['Alice', 'Bob', 'Charlie', 'David', 'Eve'];
  const passwords = ['password123', 'securePwd', '123456', 'secretPass', 'qwerty'];
  const emails = ['alice@example.com', 'bob@example.com', 'charlie@example.com', 'david@example.com', 'eve@example.com'];
  const contacts = ['123-456-7890', '987-654-3210', '555-555-5555', '888-888-8888', '111-111-1111'];
  const status = Math.random() < 0.5 ? 0 : 1; // Randomly set status to 0 or 1

  const randomIndex = Math.floor(Math.random() * names.length);
  const name = names[randomIndex];
  const password = passwords[randomIndex];
  const email = emails[randomIndex];
  const contact = contacts[randomIndex];

  const dataObject = {
    name,
    password,
    email,
    contact,
    status,
  };

  return dataObject;
}
