const { response } = require('express');
const db = require('../../../../db');
const { success, error } = require('../../helpers/response.js')
const _ = require("lodash");
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv');

exports.register = [
  async (request, response) => {
    try {
      let dummyUser = request.body;
      dummyUser.password = await bcrypt.hash(dummyUser.password, 10);
      const newUser = await db('users').insert(dummyUser);
      return success(response, newUser, 201, "data success.");
    } catch (err) {
      return error(response, err.message);
    }
  },
];

exports.login = [
  async (request, response) => {
    try {
      let data = request.body;
      const { password, ...user } = await db("users").where({ 'email': data.email }).first();
      if (password) {
        let res = await bcrypt.compare(data.password, password);
        let token = jwt.sign(user, process.env.JWT_SECRET_KEY, { expiresIn: '1s' });
        return (res) ? success(response, { token }, 201, "login success") : error(response, { message: "wrong password" });
      } else {
        return error(response, { message: "User Not Found." });
      }
    } catch (err) {
      return error(response, { message: err.message })
    }
  }
]

exports.logout = [
  async (request, response) => {
    try {
      let token = request.headers.authorization;
      token = token.split(' ')[1];
      // set expiresIn now
      let destroy = jwt.sign(token, process.env.JWT_SECRET_KEY, { expiresIn: 60 });
      console.log(destroy);
      return (destroy) ? success(response, { destroy }, 201, "logout success") : error(response, { message: "User Not Found." });
    } catch (err) {
      return error(response, { message: err.message })
    }
  }
]