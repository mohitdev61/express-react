// Update with your config settings.

/**
 * @type { Object.<string, import("knex").Knex.Config> }
 */
// below is for production database setup
let hostNameRds = 'database-1.c6ot3k8vzuyz.us-east-2.rds.amazonaws.com'; 
let hostNameIp = '3.136.33.173'; 
let hostNameLocal = '12.0.0.1'; 

let Database = 'express_app';
let username = 'root';
let password = '';

module.exports = {
  development: {
    client: 'mysql2',
    connection: {
      database: 'express_app',
      user:     'root',
      password: ''
    },
    migrations: {
      directory: './db/migrations',
      tableName: 'knex_migrations'
    },
    seeds: {
      directory: './db/seeds'
    }
  },

  staging: {
    client: 'mysql2',
    connection: {
      database: 'express_app',
      user:     'root',
      password: ''
    },
    pool: {
      min: 2,
      max: 10
    },
    migrations: {
      directory: './db/migrations',
      tableName: 'knex_migrations'
    },
    seeds: {
      directory: './db/seeds'
    }
  },
  production: {
    client: 'mysql2',
    connection: {
      host: hostNameRds,
      database: Database,
      user:     username,
      password: password,
    },
    migrations: {
      directory: './db/migrations',
      tableName: 'knex_migrations'
    },
    seeds: {
      directory: './db/seeds'
    }
  }

};
