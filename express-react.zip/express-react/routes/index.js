var express = require('express');
var router = express.Router();

const { totalUsers, addUsers } = require('../app/v1/controllers/users');
const { testLodash } = require('../app/v1/controllers/test-lodash');
const {register, login, logout} = require('../app/v1/controllers/auth');

// Middlewares
const { auth } = require('../app/v1/middlewares')

// Auth routes
router.post('/register', register);
router.post('/login', login);
router.post('/logout', auth, logout);

/* Users */
router.get('/total-users', auth , totalUsers);
router.post('/users', auth, addUsers);
router.post('/test-lodash', auth, testLodash);


module.exports = router;

